<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Curtida extends CI_Controller
{
    //mudar o model por causa dos arrays
    //vai no Controller Usuario
    public function curtida(){
        $this->load->model("Model_postagem");
        //$postagem = $this->Model_postagem->buscaPost($); criar ou esperar função para tal
        //transformar as informações em um array se pah
        $this->load->model("Model_curtida");
        $dados['num_curtidas'] = $this->Model_curtida->numerocurtidas($idself, $tipo);
    }

    public function curtir() {

        $this->load->model("Model_curtida");
        $user = $this->session->userdata("usuario_logado");
        $curtida = array(
            "idself" => $user['idself'],
            "iduser" => $user['iduser'],
            "tipo" => $user['tipo']
        );
        $this->Model_curtida->insertcurtida($curtida);
        redirect('to perdido');
    }

    public function descurtir() {

        $this->load->model("Model_curtida");
        $user = $this->session->userdata("usuario_logado");
        $curtida = array(
            "idself" => $user['idself'],
            "iduser" => $user['iduser'],
            "tipo" => $user['tipo']
        );
        $this->Model_curtida->descurtir($curtida);
        redirect('to perdido');
    }
}