<?php


class Model_curtida extends CI_Model
{
    public function numerocurtidas($idself, $tipo){
        return ($this->db->query("SELECT idcurtida
                                  FROM curtidas
                                  WHERE idself = $idself
                                  AND tipo = $tipo")->num_rows());
    }

    public function insertcurtida($idself,$iduser,$tipo){
        $sql = "INSERT INTO curtidas (idself,iduser,tipo) VALUES (".$this->db->escape($idself).",".$this->db->escape($iduser).",".$this->db->escape($tipo).")";
        $this->db->query($sql);
        echo $this->db->affected_rows();
    }

    public function descurtir($idself,$iduser,$tipo){
        $this->db->where('idself', $idself);
        $this->db->where('iduser', $iduser);
        $this->db->where('tipo', $tipo);
        $this->db->delete('curtidas');
    }

    public function verificarcurtida($idself,$iduser,$tipo){
        return ($this->db->query("SELECT idcurtida
                                  FROM curtida
                                  WHERE idself = $idself
                                  AND iduser = $iduser
                                  AND tipo = $tipo")->num_rows());
    }
}